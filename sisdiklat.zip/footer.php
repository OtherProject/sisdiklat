<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.0
        </div>
        <strong>Copyright &copy; 2018-2019 <a href="http://ambaratan.com">SISDIKLAT BPK RI</a>.</strong> All rights reserved.
      </footer>